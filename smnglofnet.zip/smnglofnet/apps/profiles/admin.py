from django.contrib import admin
from .models import PersonalAccount

admin.site.register(PersonalAccount)

