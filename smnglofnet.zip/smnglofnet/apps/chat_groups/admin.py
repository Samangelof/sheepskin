from django.contrib import admin
from .models import GroupChat, UserSendMessageInGroup


admin.site.register(GroupChat)
admin.site.register(UserSendMessageInGroup)
