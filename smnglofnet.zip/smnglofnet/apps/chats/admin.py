from django.contrib import admin
from .models import Messages

admin.site.register(Messages)

